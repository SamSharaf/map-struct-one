create view wmt_division_department_hierarchy as
select 1 AS `division`,
       1 AS `division_id`,
       1 AS `super_department`,
       1 AS `super_department_id`,
       1 AS `department`,
       1 AS `department_id`;

